Please start here: 
http://www.unreal4ar.com/documentation/