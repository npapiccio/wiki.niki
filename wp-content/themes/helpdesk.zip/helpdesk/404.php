<div class="not-found">
  <h1><i class="icon icon-Close"></i></h1>
  <h1><?php _e('Sorry, but the page you were trying to view does not exist.', 'pressapps'); ?></h1>
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <?php get_template_part('templates/search', 'form'); ?>
    </div>
  </div>
</div>
