<?php

/**
 * Loads the textdomain
 */
function palo_action_load_textdomain() {
	global $palo_textdomain, $palo_basename;
	load_plugin_textdomain( $palo_textdomain, false, dirname( $palo_basename ) . '/lang/' );
}

/**
 * Start a session in not already done
 */
function palo_action_session_start() {
	
	global $palo_helper;

	if ( ! session_id() ) {
		session_start();
	}

	/**
	 * Track previous equation
	 */
	if ( ! empty( $_SESSION[ 'palo_captcha_equation' ] ) ) {
		$palo_helper[ 'palo_captcha_equation' ] = $_SESSION[ 'palo_captcha_equation' ];
	}

	/**
	 * Generate new equation
	 */
	$_SESSION[ 'palo_captcha_equation' ] = palo_captcha_equation();
}
