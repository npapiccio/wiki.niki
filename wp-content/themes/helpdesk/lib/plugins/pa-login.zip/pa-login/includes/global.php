<?php

/**
 * @file
 * Global actions/filter calls
 */

add_action( 'plugins_loaded', 'palo_action_load_textdomain' );
